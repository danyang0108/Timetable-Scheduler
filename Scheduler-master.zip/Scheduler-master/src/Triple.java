public class Triple{
    int x, y, z;
    public Triple(int x, int y, int z){
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
