public class Pair{
    int a; //Course slot
    int b; //Students in course
    public Pair(int a, int b){
        this.a = a;
        this.b = b;
        // hoang commits
    }
}
