public class Final{
    //Used to store a student's information (final)
    String FN, LN;
    int G;
    String[] C;
    public Final(String FN, String LN, int G, String[] C){
        this.FN = FN;
        this.LN = LN;
        this.G = G;
        this.C = C;
    }
}
